MATRIX MONEY — BRAND & WEBSITE ASSETS
Packaged 2026-09-18

WHAT'S IN THIS PACKAGE
  index.html            Home page (with rate/qualify calculator links)
  about.html            About page
  services/             Seven service pages: second mortgages, home equity loans,
                        mortgage renewals, debt consolidation, bad credit, self-employed
  contact.html          Contact page
  faq.html              FAQ page
  education.html        Education page
  assets/
    matrix-money-logo.png   Primary logo — full resolution, transparent-ready PNG
    style.css               Site stylesheet (colours, type, layout tokens)
    app.js                  Site behaviour (calculator, form handling)

HOW TO VIEW IT LOCALLY
  Open index.html in any browser. All pages are static HTML — no server needed.

STATUS
  The site is built and complete but NOT yet published to a domain.
  To publish, it needs hosting + a domain (matrixmoney.ca is currently unregistered).
