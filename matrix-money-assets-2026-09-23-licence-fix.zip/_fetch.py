import subprocess, json, time, base64
import websocket as ws

def fetch(url):
    target = subprocess.run(['curl','-s','-X','PUT', f'http://localhost:9222/json/new?{url}'],
        capture_output=True, text=True).stdout
    info = json.loads(target)
    wsurl = info['webSocketDebuggerUrl']
    w = ws.create_connection(wsurl, timeout=30)
    w.send(json.dumps({"id":1,"method":"Page.enable"}))
    w.send(json.dumps({"id":2,"method":"Page.navigate","params":{"url":url}}))
    time.sleep(6)
    w.send(json.dumps({"id":3,"method":"Runtime.evaluate","params":{"expression":"document.body ? document.body.innerText : ''","returnByValue":True}}))
    txt = ""
    while True:
        m = json.loads(w.recv())
        if m.get("id") == 3:
            txt = m["result"]["result"].get("value","")
            break
    w.close()
    print(txt[:5000])

fetch("https://shutterb.co")
