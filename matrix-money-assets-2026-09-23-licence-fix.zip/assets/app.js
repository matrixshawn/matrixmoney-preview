/* Matrix Money — interactions: calculator, FAQ accordion, AI chat, rate ticker */
(function(){
  // ---- Mortgage payment calculator ----
  function calcPayment(){
    var P = parseFloat(document.getElementById('calc-amount')?.value||0);
    var r = parseFloat(document.getElementById('calc-rate')?.value||0)/100/12;
    var n = parseInt(document.getElementById('calc-term')?.value||25)*12;
    var amt=document.getElementById('calc-amount'), rt=document.getElementById('calc-rate'), tr=document.getElementById('calc-term');
    document.getElementById('calc-amt-out').textContent = '$'+(+amt.value).toLocaleString();
    document.getElementById('calc-rate-out').textContent = (+rt.value).toFixed(2)+'%';
    document.getElementById('calc-term-out').textContent = tr.value+' yrs';
    var pmt=0;
    if(r>0){ pmt = P*r/(1-Math.pow(1+r,-n)); } else { pmt = P/n; }
    document.getElementById('calc-result').textContent = '$'+pmt.toFixed(0);
    // 5-year interest saved vs credit card (illustrative)
    var interest = pmt*n - P;
    document.getElementById('calc-interest').textContent = '$'+Math.round(interest).toLocaleString();
  }
  window.calcPayment = calcPayment;
  // bind on load
  document.addEventListener('DOMContentLoaded', function(){
    ['calc-amount','calc-rate','calc-term'].forEach(function(id){
      var el=document.getElementById(id); if(el) el.addEventListener('input', calcPayment);
    });
    if(document.getElementById('calc-amount')) calcPayment();

    // ---- FAQ accordion ----
    document.querySelectorAll('.qa button').forEach(function(b){
      b.addEventListener('click', function(){
        b.parentElement.classList.toggle('open');
      });
    });

    // ---- AI chat (rule-based assistant) ----
    var fab=document.getElementById('chatFab'), box=document.getElementById('chatBox');
    if(fab&&box){
      fab.addEventListener('click', function(){ box.classList.toggle('show'); });
      document.getElementById('chatClose').addEventListener('click', function(){ box.classList.remove('show'); });
      var input=document.getElementById('chatInput'), body=document.getElementById('chatBody');
      function botSay(t){ var d=document.createElement('div'); d.className='bub bot'; d.textContent=t; body.appendChild(d); body.scrollTop=body.scrollHeight; }
      function meSay(t){ var d=document.createElement('div'); d.className='bub me'; d.textContent=t; body.appendChild(d); body.scrollTop=body.scrollHeight; }
      var KB=[
        {k:['rate','rates','interest'],a:'Today’s featured Ontario rates: 5-yr fixed from 4.99%, 3-yr fixed from 4.79%, 5-yr variable from 5.15% (indicative, subject to qualification). Want a personalized quote? Call 855.55.FUNDS.'},
        {k:['second mortgage','equity','heloc'],a:'A second mortgage or home-equity loan lets you access up to 80% of your home’s value. Great for debt consolidation, renovations, or tax bills. Start a pre-qualification above — no credit impact.'},
        {k:['bad credit','poor credit','refused','denied'],a:'We specialize in solution-based lending — bad credit, recent defaults, and prior refusals are routinely approved through our private & B-lender network. Call 855.55.FUNDS for a confidential review.'},
        {k:['renew','renewal'],a:'Renewing? We compare 40+ lenders so you keep the best rate at maturity — often without re-qualifying. Start a pre-qual above or call 855.55.FUNDS.'},
        {k:['debt','consolidat'],a:'A debt-consolidation mortgage rolls high-interest debts into one lower monthly payment using your home equity. Most clients cut payments 30–50%. Use the calculator to estimate savings.'},
        {k:['self employed','self-employ'],a:'Self-employed? We use stated income and 12 months of bank deposits — no T4s required for many programs. Call 855.55.FUNDS.'},
        {k:['contact','call','phone','talk'],a:'Reach us 24/7 at 855.55.FUNDS (855-553-8637) or email matrix@mmgb.ca. We answer live, day and night.'},
        {k:['pre','qualif','apply'],a:'The pre-qualification form above takes 60 seconds and won’t affect your credit. A broker calls you within one business hour.'}
      ];
      function reply(msg){
        msg=msg.toLowerCase();
        for(var i=0;i<KB.length;i++){ for(var j=0;j<KB[i].k.length;j++){ if(msg.indexOf(KB[i].k[j])>-1){ return KB[i].a; } } }
        return 'Thanks! A Matrix broker can give you the exact answer — call 855.55.FUNDS (24/7) or email matrix@mmgb.ca and we’ll follow up within one business hour.';
      }
      document.getElementById('chatSend').addEventListener('click', function(){
        var v=input.value.trim(); if(!v) return; meSay(v); input.value=''; setTimeout(function(){ botSay(reply(v)); }, 450);
      });
      input.addEventListener('keydown', function(e){ if(e.key==='Enter'){ document.getElementById('chatSend').click(); } });
    }

    // ---- mobile menu ----
    var mb=document.getElementById('menuBtn');
    if(mb){ mb.addEventListener('click', function(){ document.getElementById('navLinks').classList.toggle('show'); }); }
  });
})();
